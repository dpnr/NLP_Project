import nltk
nltk.download()
