def weapons():
    return ['grenade','dynamite','explosive','explosives','rocket','machineguns','machinegun','bomb','bombs']