# NLP_Project

Run the project as.

python nlpProject.py